package com.example.ejercicio2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {
    private Button btnlink1;
    private Button btnlink2;
    private Button btnlink3;
    private Button btnlink4;

    private String url1;
    private String url2;
    private String url3;
    private String url4;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.menu_layout);
        btnlink1 =findViewById(R.id.button_1);
        btnlink2 =findViewById(R.id.button_2);
        btnlink3 =findViewById(R.id.button_3);
        btnlink4 =findViewById(R.id.button_4);


        btnlink4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String imdUrl4 = "https://www.asus.com/co/store/?utm_source=google&utm_medium=cpc&utm_campaign=ASUS.CO.Notebook.eshop.CONV.2022.Q1_Search_Google.AdWords_CO_Notebook_Text.Ad_BRANDED.STD&gad_source=1&gclid=CjwKCAjw_LOwBhBFEiwAmSEQAev3saqJGaEhFjxvvrPlmSoc7bwc0ILLWmSip-bpcZW5UT6pEA7YKRoCX1gQAvD_BwE";
                Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(imdUrl4));
                startActivity(intent);
            };

        });

        btnlink1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String imdUrl1 = "https://www.lamilkeria.co/";
                Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(imdUrl1));
                startActivity(intent);
            };

        });

        btnlink2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String imdUrl2 = "https://www.musicca.com/es/guitarra";
                Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(imdUrl2));
                startActivity(intent);
            };

        });

        btnlink3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String imdUrl3 = "https://simpsonswiki.com/wiki/Main_Page";
                Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(imdUrl3));
                startActivity(intent);
            };

        });



    };

};